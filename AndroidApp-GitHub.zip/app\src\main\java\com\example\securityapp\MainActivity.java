package com.example.securityapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    private WebView webView;
    private ProgressBar progressBar;
    private Button btnHome, btnToolbox, btnProtection, btnTaskCenter, btnProfile;
    private String baseUrl = "http://38.60.199.237:8080";
    
    // 各个页面的URL路径（根据实际网站结构调整）
    private String[] pageUrls = {
        "/",           // 首页
        "/toolbox",    // 工具箱
        "/protection", // 防护
        "/tasks",      // 任务中心
        "/profile"     // 个人中心
    };
    
    private int currentPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        setupWebView();
        setupButtons();
        loadPage(0); // 默认加载首页
    }
    
    private void initViews() {
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        btnHome = findViewById(R.id.btnHome);
        btnToolbox = findViewById(R.id.btnToolbox);
        btnProtection = findViewById(R.id.btnProtection);
        btnTaskCenter = findViewById(R.id.btnTaskCenter);
        btnProfile = findViewById(R.id.btnProfile);
    }
    
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);
        webSettings.setDefaultTextEncodingName("utf-8");
        
        // 允许混合内容（HTTP和HTTPS）
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        });
    }
    
    private void setupButtons() {
        btnHome.setOnClickListener(v -> {
            selectButton(0);
            loadPage(0);
        });
        
        btnToolbox.setOnClickListener(v -> {
            selectButton(1);
            loadPage(1);
        });
        
        btnProtection.setOnClickListener(v -> {
            selectButton(2);
            loadPage(2);
            showAccessibilityDialog();
        });
        
        btnTaskCenter.setOnClickListener(v -> {
            selectButton(3);
            loadPage(3);
        });
        
        btnProfile.setOnClickListener(v -> {
            selectButton(4);
            loadPage(4);
        });
    }
    
    private void selectButton(int index) {
        // 重置所有按钮状态
        btnHome.setSelected(false);
        btnToolbox.setSelected(false);
        btnProtection.setSelected(false);
        btnTaskCenter.setSelected(false);
        btnProfile.setSelected(false);
        
        // 设置当前选中的按钮
        switch (index) {
            case 0:
                btnHome.setSelected(true);
                break;
            case 1:
                btnToolbox.setSelected(true);
                break;
            case 2:
                btnProtection.setSelected(true);
                break;
            case 3:
                btnTaskCenter.setSelected(true);
                break;
            case 4:
                btnProfile.setSelected(true);
                break;
        }
        
        currentPage = index;
    }
    
    private void loadPage(int pageIndex) {
        String url = baseUrl + pageUrls[pageIndex];
        progressBar.setVisibility(View.VISIBLE);
        webView.loadUrl(url);
    }
    
    private void showAccessibilityDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.accessibility_permission_title)
                .setMessage(R.string.accessibility_permission_message)
                .setPositiveButton(R.string.ok, (dialog, which) -> {
                    // 打开无障碍设置页面
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivity(intent);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
