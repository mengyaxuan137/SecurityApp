# 安全防护助手 Android 应用

这是一个Android应用，提供安全防护功能，包含5个主要功能模块。

## 功能特性

- **首页**: 显示主要功能入口
- **工具箱**: 提供各种安全工具
- **防护**: 安全防护功能（需要无障碍权限）
- **任务中心**: 任务管理和监控
- **个人中心**: 用户设置和个人信息

## 技术特性

- 支持Android 15 (API 35)
- 使用WebView显示网页内容
- 集成无障碍服务
- 现代化Material Design界面
- 支持网络内容加载

## 构建说明

### 环境要求

- Android Studio Arctic Fox 或更高版本
- JDK 8 或更高版本
- Android SDK API 35

### 构建APK

#### Windows用户
```bash
build-apk.bat
```

#### Linux/Mac用户
```bash
./build-apk.sh
```

#### 手动构建
```bash
# 清理项目
./gradlew clean

# 构建Debug版本
./gradlew assembleDebug

# 构建Release版本
./gradlew assembleRelease
```

### 安装APK

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## 权限说明

应用需要以下权限：

- `INTERNET`: 访问网络内容
- `ACCESS_NETWORK_STATE`: 检查网络状态
- `BIND_ACCESSIBILITY_SERVICE`: 无障碍服务
- `SYSTEM_ALERT_WINDOW`: 系统窗口权限

## 无障碍服务

点击"防护"按钮时会提示开启无障碍服务权限。这是为了提供更好的安全防护功能。

## 网络配置

应用默认连接到 `http://38.60.199.237:8080`，您可以在 `MainActivity.java` 中修改 `baseUrl` 变量来更改目标服务器。

## 项目结构

```
app/
├── src/main/
│   ├── java/com/example/securityapp/
│   │   ├── MainActivity.java          # 主Activity
│   │   └── AccessibilityService.java # 无障碍服务
│   ├── res/
│   │   ├── layout/
│   │   │   └── activity_main.xml      # 主界面布局
│   │   ├── values/
│   │   │   ├── strings.xml            # 字符串资源
│   │   │   ├── colors.xml             # 颜色资源
│   │   │   └── themes.xml             # 主题配置
│   │   └── xml/
│   │       ├── accessibility_service_config.xml
│   │       ├── data_extraction_rules.xml
│   │       └── backup_rules.xml
│   └── AndroidManifest.xml            # 应用清单
└── build.gradle                       # 构建配置
```

## 注意事项

1. 确保目标服务器 `38.60.199.237:8080` 可以正常访问
2. 无障碍服务需要用户手动开启
3. 应用支持Android 7.0 (API 24) 及以上版本
4. 建议在真机上测试无障碍功能

## 开发说明

如需修改网页URL路径，请编辑 `MainActivity.java` 中的 `pageUrls` 数组：

```java
private String[] pageUrls = {
    "/",           // 首页
    "/toolbox",    // 工具箱
    "/protection", // 防护
    "/tasks",      // 任务中心
    "/profile"     // 个人中心
};
```
